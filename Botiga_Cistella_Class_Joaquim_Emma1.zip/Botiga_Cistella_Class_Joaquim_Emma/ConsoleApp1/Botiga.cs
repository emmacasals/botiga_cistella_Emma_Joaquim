﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Runtime.ConstrainedExecution;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ConsoleApp1
{
    internal class Botiga
    {
        //Atributs 
        private string nomBotiga;// nom de la botiga
        private Producte[] productes;// Serà una taula d'objectes tipus Producte
        private int nElements;//enter que controlarà el número de productes a la botiga (número d’elements de la taula)


        //Constructors
        /// <summary>
        /// 
        /// </summary>
        public Botiga()
        {
            NomBotiga = "";
            productes = new Producte[10];
            nElements = 0;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="nomBotiga"></param>
        public Botiga(string nomBotiga)
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="nomBotiga"></param>
        /// <param name="nombreProductes"></param>
        public Botiga(string nomBotiga, int nombreProductes)
        {
            NomBotiga = nomBotiga;
            nombreProductes = 10;
            // productes = new Producte[nombreProductes];
            nElements = 0;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="nomBotiga"></param>
        /// <param name="productes"></param>
        public Botiga(string nomBotiga, Producte[] productes)
        {
            NomBotiga = nomBotiga;
            nElements = 0;
            this.productes = productes;
            for (int i = 0; i < productes.Length; i++)
            {
                // Comprova si el producte que hi ha a la posició actual no té valor 0
                if (productes[i] != null)
                {
                    nElements++;
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="nomBotiga"></param>
        /// <param name="productes"></param>
        /// <param name="nElements"></param>
        public Botiga(string nomBotiga, int[] productes, int nElements)
        {
        }

        //Botiga ["pomes"]---->pomes
        //indexof-->"pomes"  - -1    -pos


        //Propietats
        /// <summary>
        /// 
        /// </summary>
        public string NomBotiga
        {
            get { return nomBotiga; }
            set { nomBotiga = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Producte[] Productes
        {
            get { return productes; }
            set { productes = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int NElements
        {
            get { return nElements; }
            set { nElements = value; }
        }


        //Mètodes  //Acabar metodes0
        public int EsapiLliure()
        {
            for (int i = 0; i < productes.Length; i++)
            {
                if (productes[i] == null)
                {
                    return i;
                }
            }
            return -1;
        }

        public int Index(string producte)
        {
            for (int i = 0; i < productes.Length; i++)
            {
                if (productes[i].Nom == producte)
                {
                    return i;
                }
            }
            return -1;
        }

            public bool AfegirProducte(Producte producte)
        {
            int posicio = EsapiLliure();
            if (posicio != -1)
            {
                productes[posicio] = producte;
                nElements++;
                return true;
            }
            else
            {
                Console.WriteLine("La botiga està plena. Voleu ampliar la botiga?");
                return false;
            }
        }


            public bool AfegirProducte(Producte[] productes)
            {
                if (nElements + productes.Length <= this.productes.Length)
                {
                for (int i = 0; i < productes.Length; i++)
                {
                    AfegirProducte(productes[i]);
                }
                return true;
            }
                else
                {
                    Console.WriteLine("No hi ha prou espai a la botiga. Voleu ampliar-la?");
                    return false;
                }
            }
       


        public void AmpliarBotiga(int num)
        {
            Array.Resize(ref productes, productes.Length + num);
        }

        public bool ModificarPreu(string nom, double preu)
        {
            int index = Index(nom);
            bool modificat = false;
            if (index != -1)
            {
                modificat = true;
                productes[Index(nom)].Preu_sense_iva = preu;
            }
            else
            {
                Console.WriteLine("No trobat el producte...");
            }
            return modificat;
        }
       
        public bool BuscarProducte(Producte producte)
        {
            return BuscarProducte(producte.Nom);
        }

        public bool BuscarProducte(string producte)
        {
            for (int i = 0; i < productes.Length; i++)
            {
                if (productes[i].Nom == producte)
                {
                    return true;
                }
            }
            return false;
        }

        public bool ModificarProducte(Producte producte, string nouNom, double nouPreu, int novaQuantitat)
        {
            for (int i = 0; i < productes.Length; i++)
            {
                if (productes[i] != null && productes[i].Equals(producte))
                {
                    productes[i].Nom = nouNom;
                    productes[i].Preu_sense_iva = nouPreu;
                    productes[i].Quantitat = novaQuantitat;
                    return true;
                }
            }
            return false;
        }


        public void OrdenarProducte()
        {
            Array.Sort(productes, (p1, p2) => string.Compare(p1.Nom, p2.Nom));
        }

        public void OrdenarPreus()
        {
            Array.Sort(productes, (p1, p2) => p1.Preu().CompareTo(p2.Preu()));
        }


        public bool EsborrarProducte(Producte producte)
        {
            for (int i = 0; i < productes.Length; i++)
            {
                if (productes[i] != null && productes[i].Equals(producte))
                {
                    Array.Copy(productes, i + 1, productes, i, nElements - i - 1);
                    productes[nElements - 1] = null;
                    nElements--;
                    return true;
                }
            }
            return false;
        }
        public void Mostra()
        {
            Console.WriteLine($"Productes de la botiga '{nomBotiga}':");
            for (int i = 0; i < productes.Length; i++)
            {
                if (productes[i] != null)
                {
                    Console.WriteLine($"Nom: {productes[i].Nom}, Preu: {productes[i].Preu:C}");
                }
            }
        }

  public override string ToString()
    {
        string result = "Botiga: " + NomBotiga + "\n";
        for (int i = 0; i < productes.Length; i++)
        {
            if (productes[i] != null)
            {
                result += productes[i].ToString() + "\n";
            }
        }
        return result;
    }

    }
}
